<?php

namespace MiniFAIR;

class Key {
	public static function create() {
	}
}